package com.example.pushtest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
